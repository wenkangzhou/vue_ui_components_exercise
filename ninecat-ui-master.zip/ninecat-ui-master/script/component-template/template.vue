<template>
  <div class="n-ComponentName">
    ComponentName
  </div>
</template>

<script>
export default {
  name: 'NComponentName'
};
</script>
