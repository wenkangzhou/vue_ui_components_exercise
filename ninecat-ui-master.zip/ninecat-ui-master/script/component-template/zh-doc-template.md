
# componentName 



## 何时使用


## 代码演示

### 基本使用

:::demo
```html
<template>
  <n-componentName />
</template>
```
:::

## API

| 参数 | 说明 | 类型 | 默认值 |
| :--- | :--- | :--- | :--- |




