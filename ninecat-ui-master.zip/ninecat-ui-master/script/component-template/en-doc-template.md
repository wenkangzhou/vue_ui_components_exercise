
# componentName 


## 何时使用


##  代码演示

### 基本使用

:::demo
```html
<template>
  <n-componentName />
</template>
```
:::

## API

| Property | Description | Type | Default |
| :--- | :--- | :--- | :--- |


