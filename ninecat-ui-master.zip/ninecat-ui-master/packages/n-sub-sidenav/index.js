import nSubSidenav from './src/index.vue';

nSubSidenav.install = function (Vue) {
  Vue.component(nSubSidenav.name, nSubSidenav);
};

export default nSubSidenav;
