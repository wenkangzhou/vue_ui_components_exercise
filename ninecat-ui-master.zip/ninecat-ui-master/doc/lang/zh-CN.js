export default {
  developmentGuide: '开发指南',
  components: '组件',
  about: '介绍',
  baseComponents: '基础组件',
  data: '数据',
  dataEntry: '数据录入'
};
