export default {
  developmentGuide: 'Development Guide',
  components: 'Components',
  about: 'About',
  baseComponents: 'Base Components',
  data: 'Data',
  dataEntry: 'Data Entry'
};
